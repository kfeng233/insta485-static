"""Build static HTML site from directory of HTML templates and plain files."""
import os
import pathlib
import json
import shutil
import click
import jinja2
from jinja2 import TemplateSyntaxError


def read_config(input_dir):
    """Read and load config file, return JSON data."""
    input_dir = pathlib.Path(input_dir)
    config_path = os.path.join(input_dir, "config.json")
    config_filename = pathlib.Path(config_path)
    try:
        with config_filename.open(encoding="utf-8") as config_file:
            config_objects = json.load(config_file)
        return config_objects[0]
    except FileNotFoundError:
        click.echo(f"Error: {config_file} not found")
        return None
    except json.JSONDecodeError as err:
        click.echo(f"Error: {config_file}")
        click.echo(f"Expecting value: line {err.lineno}\
                   column {err.colno} (char {err.pos})")
        return None


def fill_template(input_dir, config_objects):
    """Fill template with JSON data and return a rendered template."""
    template_dir = os.path.join(input_dir, "templates")
    template_env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(template_dir)),
        autoescape=jinja2.select_autoescape(['html', 'xml'])
    )
    try:
        template = template_env.get_template("index.html")
        output_file = template.render(words=config_objects['context']['words'])
        return output_file
    except TemplateSyntaxError as err:
        click.echo(f"Error: {err} ")
        click.echo(f"Unexpected end of template. Jinja was looking \
                   for the following tags: {'endfor'} or {'else'}. The \
                   innermost block that needs to be closed is {'for'}.")
        return None


def write_output(input_dir, output_dir, config_objects,
                 rendered_template, verbose):
    """Write a output HTML file and copy static directory."""
    if os.path.exists(output_dir):
        click.echo(f"Error: {output_dir} already exists")
    else:
        os.makedirs(output_dir)
        url = pathlib.Path(config_objects['url'].lstrip("/"))
        output_path = pathlib.Path(output_dir/url/"index.html")
        with open(output_path, 'w', encoding="utf-8") as file:
            file.write(rendered_template)
        # if static exists, copy its directory
        copy_dir(input_dir, output_dir, verbose)
        # verbose option
        if verbose:
            click.echo(f"Rendered index.html -> {output_path}")


def copy_dir(input_dir, output, verbose):
    """Copy static directory to the input directory."""
    dst_dir = output
    src_dir = os.path.join(input_dir, "static")
    if os.path.exists(src_dir):
        shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)
        # verbose option
        if verbose:
            click.echo(f"Copied {src_dir} -> {dst_dir}")


@click.command()
@click.argument("input_dir", nargs=1, type=click.Path(exists=True))
@click.option('--output', '-o', type=click.Path(), help="Output directory.")
@click.option('--verbose', '-v', is_flag=True, help="Print more output.")
def main(input_dir, output, verbose):
    """Templated static website generator."""
    input_dir = pathlib.Path(input_dir)
    config_objects = read_config(input_dir)
    if config_objects is None:
        return
    rendered_template = fill_template(input_dir, config_objects)
    if rendered_template is None:
        return
    # non --output option -> use default
    if output is None:
        output = pathlib.Path(input_dir/"html")
    write_output(input_dir, output, config_objects, rendered_template, verbose)


if __name__ == "__main__":
    main()
