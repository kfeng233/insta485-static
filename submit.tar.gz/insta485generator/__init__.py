"""Initialize insta485 generator."""
